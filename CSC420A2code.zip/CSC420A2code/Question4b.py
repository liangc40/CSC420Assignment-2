import cv2
import math
import numpy as np
from scipy import spatial
import matplotlib.pyplot as plt

def display_image(img, file_name=None):
    flt_img = img.astype(float)
    img_max, img_min = np.max(flt_img), np.min(flt_img)

    norm_img = (((flt_img - img_min) / (img_max - img_min)) * 255).astype(np.uint8)

    if len(img.shape) == 2:
        plt.imshow(norm_img, cmap='gray')
    elif (len(img.shape) == 3):
        plt.imshow(cv2.cvtColor(norm_img, cv2.COLOR_BGR2RGB))
    plt.show()

    if file_name:
        cv2.imwrite(file_name, norm_img)

def get_keypoints_and_features(img):
    sift = cv2.xfeatures2d.SIFT_create(1000)
    keypoints, descriptors = sift.detectAndCompute(img, None)
    return keypoints, descriptors


def establish_feature_correspondence(img1, img2, keypoint_1, keypoint_2, descriptor_1, descriptor_2, threshold):
    distances = spatial.distance.cdist(descriptor_1, descriptor_2, "euclidean")
    sorted_distances = np.argsort(distances, axis=1)
    closest, second_closest = sorted_distances[:, 0], sorted_distances[:, 1]

    ratio_array = np.zeros((closest.shape[0]))
    for i in range(closest.shape[0]):
        ratio = closest[i] / second_closest[i]
        if ratio < threshold:
            ratio_array[i] = ratio
        else:
            ratio_array[i] = 0

    remaining_descriptor_1_index = np.nonzero(ratio_array)[0]
    remaining_descriptor_2_index = closest[remaining_descriptor_1_index]

    pairs = np.stack((remaining_descriptor_1_index, remaining_descriptor_2_index)).transpose()
    pair_distances = distances[pairs[:, 0], pairs[:, 1]]
    sorted_dist_indices = np.argsort(pair_distances)
    sorted_pairs = pairs[sorted_dist_indices]

    location_pairs = []
    for i in range(10):
        temp = []
        ptr_1 = (keypoint_1[sorted_pairs[i, 0]])
        ptr_2 = (keypoint_2[sorted_pairs[i, 1]])
        temp.append(ptr_1)
        temp.append(ptr_2)
        location_pairs.append(temp)

    draw_matches(img1, img2, location_pairs)

    return len(pairs)

def draw_matches(img1, img2, location_pairs):
    result = np.concatenate((img1, img2), axis=1)
    for location_pair in location_pairs:
        x_ptr_0,  y_ptr_0 = location_pair[0].pt
        x_ptr_1, y_ptr_1 = location_pair[1].pt
        x_ptr_1 += img1.shape[1]
        cv2.line(result, (int(x_ptr_0), int(y_ptr_0)), (int(x_ptr_1), int(y_ptr_1)), (255, 0, 0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    display_image(result)
    return 0

if __name__ == '__main__':
    img1 = cv2.imread('sample1.jpg')
    img2 = cv2.imread('sample2.jpg')
    kp1, dest1 = get_keypoints_and_features(img1)
    kp2, dest2 = get_keypoints_and_features(img2)
    establish_feature_correspondence(img1, img2, kp1, kp2, dest1, dest2, 0.5)

    # number_of_matches = []
    # threshold_seq = np.linspace(0, 1, num=10)
    # for threshold in threshold_seq:
    #     num_of_match = establish_feature_correspondence(img1, img2, kp1, kp2, dest1, dest2, threshold)
    #     number_of_matches.append(num_of_match)
    #
    # plt.plot(threshold_seq, number_of_matches, label='number of matches')
    # plt.show()
