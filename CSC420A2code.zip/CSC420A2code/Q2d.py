import matplotlib.pyplot as plt
import cv2
import numpy as np

def SURF_feature_discriptor(img):
    surf = cv2.xfeatures2d.SURF_create(1000)
    keypoints, _ = surf.detectAndCompute(img, None)
    img2 =cv2.drawKeypoints(img, keypoints, np.array([]), (0,0,0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    plt.imshow(img2, cmap='gray')
    plt.show()


if __name__ == '__main__':
    img = cv2.imread('building.jpg', 0)
    SURF_feature_discriptor(img)
