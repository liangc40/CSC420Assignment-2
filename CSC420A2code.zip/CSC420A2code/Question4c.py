import cv2
import math
import numpy as np
import matplotlib.pyplot as plt

def display_image(img, file_name=None):
    flt_img = img.astype(float)
    img_max, img_min = np.max(flt_img), np.min(flt_img)

    norm_img = (((flt_img - img_min) / (img_max - img_min)) * 255).astype(np.uint8)

    if len(img.shape) == 2:
        plt.imshow(norm_img, cmap='gray')
    elif len(img.shape) == 3:
        plt.imshow(cv2.cvtColor(norm_img, cv2.COLOR_BGR2RGB))
    plt.show()

    if file_name:
        cv2.imwrite(file_name, norm_img)

def get_keypoints_and_features(img):
    sift = cv2.xfeatures2d.SIFT_create(200)
    keypoints, descriptors = sift.detectAndCompute(img, None)
    return keypoints, descriptors


def establish_feature_correspondence(img1, img2, keypoint_1, keypoint_2, descriptor_1, descriptor_2, threshold, mode):
    distances = np.zeros((len(keypoint_1), len(keypoint_2)))
    for i in range(len(keypoint_1)):
        for j in range(len(keypoint_2)):
            if mode == "L1":
                distances[i, j] = calculate_L1_norm(descriptor_1[i].reshape(-1) - descriptor_2[j].reshape(-1))
                print(distances[i, j])
            elif mode == "L2":
                distances[i, j] = calculate_L2_norm(descriptor_1[i].reshape(-1) - descriptor_2[j].reshape(-1))
            elif mode == "L3":
                distances[i, j] = calculate_L3_norm(descriptor_1[i].reshape(-1) - descriptor_2[j].reshape(-1))

    sorted_distances = np.argsort(distances, axis=1)
    closest, second_closest = sorted_distances[:, 0], sorted_distances[:, 1]

    ratio_array = np.zeros((closest.shape[0]))
    for i in range(closest.shape[0]):
        ratio = closest[i] / second_closest[i]
        if ratio < threshold:
            ratio_array[i] = ratio
        else:
            ratio_array[i] = 0

    remaining_descriptor_1_index = np.nonzero(ratio_array)[0]
    remaining_descriptor_2_index = closest[remaining_descriptor_1_index]

    pairs = np.stack((remaining_descriptor_1_index, remaining_descriptor_2_index)).transpose()
    pair_distances = distances[pairs[:, 0], pairs[:, 1]]
    sorted_dist_indices = np.argsort(pair_distances)
    sorted_pairs = pairs[sorted_dist_indices]

    location_pairs = []
    for i in range(10):
        temp = []
        ptr_1 = (keypoint_1[sorted_pairs[i, 0]])
        ptr_2 = (keypoint_2[sorted_pairs[i, 1]])
        temp.append(ptr_1)
        temp.append(ptr_2)
        location_pairs.append(temp)

    draw_matches(img1, img2, location_pairs)

    return len(pairs)

def draw_matches(img1, img2, location_pairs):
    result = np.concatenate((img1, img2), axis=1)
    for location_pair in location_pairs:
        x_ptr_0,  y_ptr_0 = location_pair[0].pt
        x_ptr_1, y_ptr_1 = location_pair[1].pt
        x_ptr_1 += img1.shape[1]
        cv2.line(result, (int(x_ptr_0), int(y_ptr_0)), (int(x_ptr_1), int(y_ptr_1)), (255, 0, 0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    display_image(result)
    return 0

def calculate_L2_norm(diff_vector):
    sum = 0
    for vec in diff_vector:
        sum += vec ** 2
    return math.sqrt(sum)

def calculate_L1_norm(diff_vector):
    return sum(abs(diff_vector))

def calculate_L3_norm(diff_vector):
    sum = 0
    for vec in diff_vector:
        sum += abs(vec ** 3)
    return sum ** (1/3)

if __name__ == '__main__':
    img1 = cv2.imread('sample1.jpg')
    img2 = cv2.imread('sample2.jpg')
    kp1, dest1 = get_keypoints_and_features(img1)
    kp2, dest2 = get_keypoints_and_features(img2)
    establish_feature_correspondence(img1, img2, kp1, kp2, dest1, dest2, 0.8, "L1")
    establish_feature_correspondence(img1, img2, kp1, kp2, dest1, dest2, 0.8, "L2")
    establish_feature_correspondence(img1, img2, kp1, kp2, dest1, dest2, 0.8, "L3")
