import matplotlib.pyplot as plt
import cv2
import numpy as np


def quadruple_image_size_by_column(input_image, total_col_num, total_row_num):
    result_image = np.zeros((total_row_num, total_col_num * 4 - 3))
    for row_num in range(total_row_num):
        whole_row = input_image[row_num, :]
        result_image[row_num, :] = upsample_one_dimension(whole_row, total_col_num)
    return result_image


def quadruple_image_size_by_row(input_image, total_col_num, total_row_num):
    result_image = np.zeros((total_row_num * 4 - 3, total_col_num))
    for col_num in range(total_col_num):
        whole_col = input_image[:, col_num]
        result_image[:, col_num] = upsample_one_dimension(whole_col, total_row_num)
    return result_image


def upsample_one_dimension(pixel_list, num):
    result_pixel_list = [None] * (num * 4 - 3)
    for i in range(num - 1):
        pix1 = pixel_list[i]
        pix2 = pixel_list[i + 1]
        result_pixel_list[i * 4] = pix1
        result_pixel_list[i * 4 + 4] = pix2
        result_pixel_list[i * 4 + 1] = pix1 + (pix2 - pix1) / 4
        result_pixel_list[i * 4 + 2] = pix1 + (pix2 - pix1) / 2
        result_pixel_list[i * 4 + 3] = pix1 + 3 * (pix2 - pix1) / 4
    return result_pixel_list



def apply_2D_filter(input_image, total_row_num, total_col_num):
    result_image = np.zeros((total_row_num * 4 - 3, total_col_num * 4 - 3))
    for i in range(total_row_num * 4 - 3):
        for j in range(total_col_num * 4 - 3):
            if i % 4 == 0 and j % 4 == 0:
                result_image[i][j] = input_image[i // 4][j // 4]
    for k in range(total_row_num * 4 -3):
        for l in range(total_col_num * 4 - 3):
            if k % 4 == 0 and l % 4 != 0:
                t = l / 4
                s = int(l/4)
                result_image[k][l] = (s - t + 1) * input_image[k // 4][s] + (t - s) * input_image[k // 4][s + 1]
    for u in range(total_row_num * 4 - 3):
        for v in range(total_col_num * 4 - 3):
            if u % 4 != 0:
                x = (u // 4) * 4
                result_image[u][v] = (x + 4 - u) * result_image[x][v] / 4 + (u - x) * result_image[x + 4][v]/4
    return result_image


if __name__ == '__main__':
    img = cv2.imread("bee.jpg").astype(np.float32)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img0 = quadruple_image_size_by_column(img[:, :, 0], img.shape[1], img.shape[0])
    img1 = quadruple_image_size_by_column(img[:, :, 1], img.shape[1], img.shape[0])
    img2 = quadruple_image_size_by_column(img[:, :, 2], img.shape[1], img.shape[0])
    result_image_col = np.zeros((img.shape[0], img.shape[1] * 4 - 3, img.shape[2]))
    result_image_col[:, :, 0] = img0
    result_image_col[:, :, 1] = img1
    result_image_col[:, :, 2] = img2
    result_image_col = result_image_col.astype(np.int32)
    plt.imshow(result_image_col)
    plt.show()

    img3 = quadruple_image_size_by_row(img[:, :, 0], img.shape[1], img.shape[0])
    img4 = quadruple_image_size_by_row(img[:, :, 1], img.shape[1], img.shape[0])
    img5 = quadruple_image_size_by_row(img[:, :, 2], img.shape[1], img.shape[0])
    result_image_row = np.zeros((img.shape[0] * 4 - 3, img.shape[1], img.shape[2]))
    result_image_row[:, :, 0] = img3
    result_image_row[:, :, 1] = img4
    result_image_row[:, :, 2] = img5
    result_image_row = result_image_row.astype(np.int32)
    plt.imshow(result_image_row)
    plt.show()

    img5 = quadruple_image_size_by_row(img0, img0.shape[1], img0.shape[0])
    img6 = quadruple_image_size_by_row(img1, img1.shape[1], img1.shape[0])
    img7 = quadruple_image_size_by_row(img2, img2.shape[1], img2.shape[0])
    result_image = np.zeros((img0.shape[0] * 4 - 3, img0.shape[1], 3))
    result_image[:, :, 0] = img5
    result_image[:, :, 1] = img6
    result_image[:, :, 2] = img7
    result_image = result_image.astype(np.int32)
    plt.imshow(result_image)
    plt.show()

    img8 = apply_2D_filter(img[:, :, 0], img.shape[0], img.shape[1])
    img9 = apply_2D_filter(img[:, :, 1], img.shape[0], img.shape[1])
    img10 = apply_2D_filter(img[:, :, 2], img.shape[0], img.shape[1])
    result_image = np.zeros((img.shape[0] * 4 - 3, img.shape[1] * 4 - 3, img.shape[2]))
    result_image[:, :, 0] = img8
    result_image[:, :, 1] = img9
    result_image[:, :, 2] = img10
    result_image = result_image.astype(np.int32)
    plt.imshow(result_image)
    plt.show()
