import cv2
import numpy as np
import matplotlib.pyplot as plt

def display_image(img, file_name=None):
    flt_img = img.astype(float)
    img_max, img_min = np.max(flt_img), np.min(flt_img)

    norm_img = (((flt_img - img_min) / (img_max - img_min)) * 255).astype(np.uint8)

    if len(img.shape) == 2:
        plt.imshow(norm_img, cmap='gray')
    elif (len(img.shape) == 3):
        plt.imshow(cv2.cvtColor(norm_img, cv2.COLOR_BGR2RGB))
    plt.show()

    if file_name:
        cv2.imwrite(file_name, norm_img)

def get_keypoints_and_features(img):
    sift = cv2.xfeatures2d.SIFT_create(1000)
    keypoints, descriptors = sift.detectAndCompute(img, None)
    img2 = cv2.drawKeypoints(img, keypoints, np.array([]), (0,255,0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    display_image(img2)
    return keypoints, descriptors


if __name__ == '__main__':
    img1 = cv2.imread('sample1.jpg')
    img2 = cv2.imread('sample2.jpg')
    get_keypoints_and_features(img1)
