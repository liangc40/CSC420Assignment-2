import cv2
import math
import numpy as np
from scipy import spatial
import matplotlib.pyplot as plt

def display_image(img, file_name=None):
    flt_img = img.astype(float)
    img_max, img_min = np.max(flt_img), np.min(flt_img)

    norm_img = (((flt_img - img_min) / (img_max - img_min)) * 255).astype(np.uint8)

    if len(img.shape) == 2:
        plt.imshow(norm_img, cmap='gray')
    elif (len(img.shape) == 3):
        plt.imshow(cv2.cvtColor(norm_img,  cv2.COLOR_RGB2BGR))
    plt.show()

    if file_name:
        cv2.imwrite(file_name, norm_img)

def get_keypoints_and_features(img):
    sift = cv2.xfeatures2d.SIFT_create(1000)
    keypoints, descriptors = sift.detectAndCompute(img, None)
    if (descriptors is None):
        descriptors = np.zeros((img.shape[0], img.shape[1]))
    img2 = cv2.drawKeypoints(img, keypoints, np.array([]), (0,255,0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    return keypoints, descriptors, img2


def establish_feature_correspondence(keypoint_1, keypoint_2, descriptor_1, descriptor_2, threshold, mode):
    distances = np.zeros((len(keypoint_1), len(keypoint_2)))
    for i in range(len(keypoint_1)):
        for j in range(len(keypoint_2)):
            if mode == "L1":
                distances[i, j] = calculate_L1_norm(descriptor_1[i].reshape(-1) - descriptor_2[j].reshape(-1))
            elif mode == "L2":
                distances[i, j] = calculate_L2_norm(descriptor_1[i].reshape(-1) - descriptor_2[j].reshape(-1))
            elif mode == "L3":
                distances[i, j] = calculate_L3_norm(descriptor_1[i].reshape(-1) - descriptor_2[j].reshape(-1))

    sorted_distances = np.argsort(distances, axis=1)
    closest, second_closest = sorted_distances[:, 0], sorted_distances[:, 1]

    ratio_array = np.zeros((closest.shape[0]))
    for i in range(closest.shape[0]):
        ratio = closest[i] / second_closest[i]
        if ratio < threshold:
            ratio_array[i] = ratio
        else:
            ratio_array[i] = 0

    remaining_descriptor_1_index = np.nonzero(ratio_array)[0]
    remaining_descriptor_2_index = closest[remaining_descriptor_1_index]


    pairs = np.stack((remaining_descriptor_1_index, remaining_descriptor_2_index)).transpose()
    pair_distances = distances[pairs[:, 0], pairs[:, 1]]
    sorted_dist_indices = np.argsort(pair_distances)
    sorted_pairs = pairs[sorted_dist_indices]

    location_pairs = []
    for i in range(10):
        temp = []
        ptr_1 = (keypoint_1[sorted_pairs[i, 0]])
        ptr_2 = (keypoint_2[sorted_pairs[i, 1]])
        temp.append(ptr_1)
        temp.append(ptr_2)
        location_pairs.append(temp)

    return location_pairs

def draw_matches(img1, img2, location_pairs):

    result = np.concatenate((img1, img2), axis = 1)
    for location_pair in location_pairs:
        x_ptr_0,  y_ptr_0 = location_pair[0].pt
        x_ptr_0 += 300
        y_ptr_0 += 300
        x_ptr_1, y_ptr_1 = location_pair[1].pt
        x_ptr_1 += img1.shape[1]
        cv2.line(result, (int(x_ptr_0), int(y_ptr_0)), (int(x_ptr_1), int(y_ptr_1)), (255, 0, 0), cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
    display_image(result)
    return 0

def calculate_L2_norm(diff_vector):
    sum = 0
    for vec in diff_vector:
        sum += vec ** 2
    return math.sqrt(sum)

def calculate_L1_norm(diff_vector):
    return sum(abs(diff_vector))

def calculate_L3_norm(diff_vector):
    sum = 0
    for vec in diff_vector:
        sum += abs(vec ** 3)
    return sum ** (1/3)

def intersection(ls1, ls2):
    ls3 = [value for value in ls1 if value in ls2]
    return ls3

if __name__ == '__main__':
    img1 = cv2.imread('colourSearch.png')
    img1 = cv2.cvtColor(img1, cv2.COLOR_BGR2RGB)
    img2 = cv2.imread('colourTemplate.png')
    img2 = cv2.cvtColor(img2, cv2.COLOR_BGR2RGB)
    img1_1 = img1[:, :, 0]
    img1_2 = img1[:, :, 1]
    img1_3 = img1[:, :, 2]
    img2_1 = img2[:, :, 0]
    img2_2 = img2[:, :, 1]
    img2_3 = img2[:, :, 2]

    kp1_1, dest1_1, img1_1_0 = get_keypoints_and_features(img1_1)
    kp2_1, dest2_1, img2_1_0 = get_keypoints_and_features(img2_1)
    set_A = establish_feature_correspondence(kp1_1, kp2_1, dest1_1, dest2_1, 0.8, "L2")

    kp1_2, dest1_2, img1_2_0 = get_keypoints_and_features(img1_2)
    kp2_2, dest2_2, img2_2_0 = get_keypoints_and_features(img2_2)
    set_B = establish_feature_correspondence(kp1_2, kp2_2, dest1_2, dest2_2, 0.8, "L2")

    kp1_3, dest1_3, img1_3_0 = get_keypoints_and_features(img1_3)
    kp2_3, dest2_3, img2_3_0 = get_keypoints_and_features(img2_3)
    set_C = establish_feature_correspondence(kp1_3, kp2_3, dest1_3, dest2_3, 0.8, "L2")

    set_to_plot = intersection(set_A, set_C)
    set_to_plot = intersection(set_B, set_to_plot)
    draw_matches(img1, img2, set_to_plot)
