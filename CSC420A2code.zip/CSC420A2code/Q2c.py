import cv2
import numpy as np


def non_maxima_suppression(img, pyramid, threshold, sigma_list):
    maxima_list = []
    for i in range(1, 4):
        upper = pyramid[i-1]
        current = pyramid[i]
        lower = pyramid[i+1]

        upper_pad = np.zeros((img.shape[0] + 2, img.shape[1] + 2))
        upper_pad[1: 1 + img.shape[0], 1: 1 + img.shape[1]] = upper[0: img.shape[0], 0: img.shape[1]]

        current_pad = np.zeros((img.shape[0] + 2, img.shape[1] + 2))
        current_pad[1: 1 + img.shape[0], 1: 1 + img.shape[1]] = current[0: img.shape[0], 0: img.shape[1]]

        lower_pad = np.zeros((img.shape[0] + 2, img.shape[1] + 2))
        lower_pad[1: 1 + img.shape[0], 1: 1 + img.shape[1]] = lower[0: img.shape[0], 0: img.shape[1]]

        patch_size = 3

        for row in range(img.shape[0]):
            for col in range(img.shape[1]):
                upper_sub = np.array(upper_pad[row: row + patch_size, col: col + patch_size])
                current_sub = np.array(current_pad[row: row + patch_size, col: col + patch_size])
                lower_sub = np.array(lower_pad[row: row + patch_size, col: col + patch_size])

                cur_max = np.concatenate((upper_sub, current_sub), axis=0)
                cur_max = np.concatenate((cur_max, lower_sub), axis=0)
                max_value = np.max(cur_max)

                if max_value == current_sub[1, 1] and np.percentile(cur_max, threshold) < current_sub[1, 1]:
                    maxima_list.append(((row, col), sigma_list[i]))
    return maxima_list


def mySift(threshold, img):
    pyramid = [np.zeros(img.shape)]
    sigma_list = [0]
    sigma = 1.6
    scaling_factor = 1

    for octave in range(5):
        gaussian_img = cv2.GaussianBlur(img, ksize=(0, 0),
                                     sigmaX=sigma * scaling_factor, sigmaY=sigma * scaling_factor)
        laplacian_img = np.abs(cv2.Laplacian(gaussian_img, ddepth=cv2.CV_32F, ksize=5, scale=1))
        pyramid.append(laplacian_img)
        scaling_factor = scaling_factor * np.sqrt(2)
        sigma_list.append(scaling_factor)

    pyramid.append(np.zeros(img.shape))

    max_list = non_maxima_suppression(img, pyramid, threshold, sigma_list)

    for data in max_list:
        cv2.circle(img, (data[0][1], data[0][0]), input(np.round(data[1])), color=(255, 0, 0))


if __name__ == '__main__':
    img = cv2.imread('bee.jpg')
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY).astype(np.float)
    mySift(90, img)
