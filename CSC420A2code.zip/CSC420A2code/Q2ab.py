import matplotlib.pyplot as plt
import random
import cv2
import numpy as np
import imutils

def calculate_components(img):
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) * 0.5
    blur = cv2.GaussianBlur(gray, (5, 5), 7)
    Ix = cv2.Sobel(blur, cv2.CV_64F, 1, 0, ksize=5)
    Iy = cv2.Sobel(blur, cv2.CV_64F, 0, 1, ksize=5)
    IxIy = np.multiply(Ix, Iy)
    Ix2 = np.multiply(Ix, Ix)
    Iy2 = np.multiply(Iy, Iy)
    Ix2_blur = cv2.GaussianBlur(Ix2, (7, 7), 10)
    Iy2_blur = cv2.GaussianBlur(Iy2, (7, 7), 10)
    IxIy_blur = cv2.GaussianBlur(IxIy, (7, 7), 10)
    return Ix2_blur, Iy2_blur, IxIy_blur


def get_trace_and_determinant(img):
    Ix2_blur, Iy2_blur, IxIy_blur = calculate_components(img)
    det = np.multiply(Ix2_blur, Iy2_blur) - np.multiply(IxIy_blur, IxIy_blur)
    trace = Ix2_blur + Iy2_blur
    return trace, det


def harris_corner_detector(img, alpha):
    trace, det = get_trace_and_determinant(img)
    return det - alpha * np.multiply(trace, trace)


def brown_corner_detector(img):
    res = np.zeros((img.shap[0], img.shape[0]))
    trace, det = get_trace_and_determinant(img)
    for i in range(trace.shape[0]):
        for j in range(trace.shape[1]):
            if trace[i][j] == 0:
                res[i][j] = 255
            else:
                res[i][j] = det[i][j] / trace[i][j]
    return res


def harris_corner_detector_by_eigenvalue(img, alpha):
    Ix2_blur, Iy2_blur, IxIy_blur = calculate_components(img)
    result = np.zeros(Ix2_blur.shape)
    for i in range(Ix2_blur.shape[0]):
        for j in range(Ix2_blur.shape[1]):
            M = np.array([[Ix2_blur[i, j], IxIy_blur[i, j]], [IxIy_blur[i, j], Iy2_blur[i, j]]])
            eigenvalues, _ = np.linalg.eig(M)
            result[i, j] = eigenvalues[0] * eigenvalues[1] - alpha * (eigenvalues[0] + eigenvalues[1]) ** 2
    return result


def brown_corner_detector_by_eigenvalue(img):
    Ix2_blur, Iy2_blur, IxIy_blur = calculate_components(img)
    result = np.zeros(Ix2_blur.shape)
    for i in range(Ix2_blur.shape[0]):
        for j in range(Ix2_blur.shape[1]):
            M = np.array([[Ix2_blur[i, j], IxIy_blur[i, j]], [IxIy_blur[i, j], Iy2_blur[i, j]]])
            eigenvalue, _ = np.linalg.eig(M)
            denominator = eigenvalue[0] + eigenvalue[1]
            if denominator == 0:
                result[i][j] = 255
            else:
                result[i][j] = eigenvalue[0] * eigenvalue[1] / denominator
    return result

def rotate_image(img):
    rotated = imutils.rotate_bound(img, 60)
    return rotated

def harris_corner_after_rotation(img, alpha):
    rotated_img = rotate_image(img)
    return harris_corner_detector(rotated_img, alpha)


if __name__ == '__main__':
    img = cv2.imread("building.jpg")
    img2 = harris_corner_detector(img, alpha=0.05)
    img3 = brown_corner_detector_by_eigenvalue(img)
    plt.imshow(img2, cmap='gray')
    plt.show()
    plt.imshow(img3, cmap='gray')
    plt.show()
    img4 = harris_corner_detector_by_eigenvalue(img, alpha=0.05)
    img5 = brown_corner_detector_by_eigenvalue(img)
    plt.imshow(img4, cmap='gray')
    plt.show()
    plt.imshow(img5, cmap='gray')
    plt.show()

    img6 = harris_corner_after_rotation(img, alpha=0.05)
    plt.imshow(img6, cmap='gray')
    plt.show()
